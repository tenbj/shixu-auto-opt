---
name: shixu-issues
description: Connect this AI client to Shixu, or record and retrieve the user's issues with confirmed provenance and read-back verification.
---

# 拾序问题记录

## 首次接入

仅当用户明确要求连接或配置拾序时，读取 https://shixu.eliasliu.cc/connect.md 和同源版本清单。识别实际运行环境及版本，只配置当前客户端；使用其原生远程 MCP，不要求拾序源码、Python、Node 或 Git。对同名不同地址/账号的连接保留原配置并说明冲突；不要覆盖其他服务。下载包核对清单 SHA256，重复安装不覆盖用户修改。

由用户在拾序网页登录和同意权限。不得读取或回显密码、OAuth 凭据、长期令牌；不要将秘密放到聊天、请求记录或普通配置示例中。需要重载时记录非秘密的配置路径、地址和当前步骤，开启新会话后继续。没有执行能力或客户端版本不支持时提供手动入口，不宣称已自动完成。

连接后调用 get_connection_context，核对账号、权限及接口版本；再 list_issues 确认工具读取。可填写可信 runtime_name/runtime_version 和本技能包版本 skill_version；它们仅为客户端声明。分别报告 Skill 是否可发现、MCP 是否已加载、账号/权限是否符合请求。若只能读，不能声称具备写权限。首次配置不写测试问题；用户同时明确要求记录问题时再执行下节。

## 日常记录

1. 阅读 references/录入与分类规则.md，保留用户原意，定义开放分类，搜索并读取相似问题。
2. 阅读 references/创建身份与模型规则.md。用 list_identities 选择真实 AI 身份；必要身份另行创建并回读。人员未确认则省略；模型未知显式传 modelInfo={}，保留已知工具与人员来源。不要从账号昵称猜测发起人。
3. 写前取最新 revision，将完整请求持久化到当前用户私有数据目录中按服务地址和 account.id 隔离的请求文件。目录建议使用系统用户数据目录下 shixu/requests；限制其他用户访问。记录新 request_id、expected_version、actor、分类及 creation；不存密码或令牌。无法持久化时先保留草稿，不发送不可恢复的写入。
4. 用户授权记录时调用 create_issue，明确授权编辑时调用 update_issue。网络超时/503结果未知时原请求原编号重放；409重读评估后新建请求；422修正后新编号。切换账号不能重放其他工作台请求。
5. 成功后 get_issue 按 ID 回读编号、标题、背景、分类、状态与六项创建快照；仅报告已确认结果。批量逐条完成，身份创建也会增加 revision。

仅记录或编辑用户明确要求的内容，不自行删除、推进状态、启动服务器或修改历史创建来源。认证由服务器控制，Skill不能扩大权限。已有连接直接使用，401恢复授权，403核对权限；日常记录不重新安装客户端或覆盖本地技能。
